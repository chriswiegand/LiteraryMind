## Packages
framer-motion | Smooth layout transitions and entry animations
date-fns | Formatting dates for books and quizzes
lucide-react | Beautiful icons for the UI

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ['Inter', 'sans-serif'],
  display: ['Playfair Display', 'serif'],
}
